﻿# LogFileCollector

**LogFileCollector** is a Windows console application built with .NET Framework 4.8.  
Virinco created this utility because installed custom converters in our WATS Client (download.wats.com) does not support subdirectory monitoring - it requires a single folder to watch.
So - we made this small utility to fill that gap. We also work on a solution to integrate this functionality directly into WATS Client in the future.
It monitors a source folder for new files and copies them to a target folder.  
Copied files are tracked persistently in a `copied.json` file to prevent duplicates, even after restarting the app.

---

## 📦 Features

- Monitors a folder using `FileSystemWatcher`
- Supports file filters (e.g. `*.log`, `*.txt`)
- Optional recursive subdirectory monitoring
- Copies files without recreating subfolder structure
- Tracks copied files using a persistent JSON log
- Supports a one-time full folder scan with the `-force` argument
- It is possible to delete the `copied.json` file to reset the tracking; all files will be copied again
- Uses Serilog for rolling file logging
- All operational parameters are configurable via application settings

---

## ⚙️ Configuration

Settings are stored in `LogFileCollector.exe.config` as XML under `<applicationSettings>`.  
You can edit these settings to control the application's behavior.

### Example `LogFileCollector.exe.config`:

```xml
<?xml version="1.0" encoding="utf-8" ?>
<configuration>
  <configSections>
    <sectionGroup name="applicationSettings" type="System.Configuration.ApplicationSettingsGroup, System, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089" >
      <section name="LogFileCollector.Properties.Settings" type="System.Configuration.ClientSettingsSection, System, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089" requirePermission="false" />
    </sectionGroup>
  </configSections>
  <startup>
    <supportedRuntime version="v4.0" sku=".NETFramework,Version=v4.8" />
  </startup>
  <applicationSettings>
    <LogFileCollector.Properties.Settings>
      <setting name="Filter" serializeAs="String">
        <value>*.log</value>
      </setting>
      <setting name="SourceFolder" serializeAs="String">
        <value>C:\SourceFolderWithSubFolders or UNC</value>
      </setting>
      <setting name="TargetFolder" serializeAs="String">
        <value>c:\programdata\virinco\wats\SampleConverterDropFolder</value>
      </setting>
      <setting name="IncludeSubdirectories" serializeAs="String">
        <value>True</value>
      </setting>
      <setting name="CopiedLogPath" serializeAs="String">
        <value>copied.json</value>
      </setting>
      <setting name="LogFilePath" serializeAs="String">
        <value>logfile-.txt</value>
      </setting>
      <setting name="LogRetainedFileCountLimit" serializeAs="String">
        <value>7</value>
      </setting>
      <setting name="LogOutputTemplate" serializeAs="String">
        <value>{Timestamp:yyyy-MM-dd HH:mm:ss} [{Level:u3}] {Message:lj}{NewLine}{Exception}</value>
      </setting>
      <setting name="FileCreatedDelayMs" serializeAs="String">
        <value>500</value>
      </setting>
      <setting name="FileNameIsUnique" serializeAs="String">
        <value>True</value>
      </setting>
    </LogFileCollector.Properties.Settings>
  </applicationSettings>
</configuration>


### Setting Descriptions

- **Filter**: File pattern to watch for (e.g., `*.log`).
- **SourceFolder**: Directory to monitor for new files.
- **TargetFolder**: Directory where files will be copied.
- **IncludeSubdirectories**: `True` to watch all subdirectories; `False` for top-level only.
- **CopiedLogPath**: Path to the JSON file that tracks already-copied files.
- **LogFilePath**: Path and pattern for the rolling log files.
- **LogRetainedFileCountLimit**: Number of log files to retain.
- **LogOutputTemplate**: Serilog output template for log entries.
- **FileCreatedDelayMs**: Milliseconds to wait after a file is created before attempting to copy.
- **FileNameIsUnique**: `True` to use only the file name for uniqueness; `False` to use the full file path.

---

## 🚀 Suggested installation

Download the LogFileCollector.zip and extract it to `C:\ProgramData\Virinco\WATS\LogFileCollector\`  (You are recommended to create and use this folder)
Modify the `LogFileCollector.exe.config` file to set the source and target folders, filters, and other settings as needed.  

## Scheduled Task Variants

The utility requires a scheduled task to start automatically at boot.  
Different environments may need different security contexts depending on how the utility should access local or network resources.  
Choose the XML variant that best matches your setup:

- **LogFileCollector_Domain.xml**  
  Use this when your environment is joined to a domain.  
  Runs under a dedicated domain service account (e.g. `DOMAIN\ServiceUser`) with stored credentials.  
  ✅ Recommended if the utility must reliably access **network shares with domain credentials**.

- **LogFileCollector_Local.xml**  
  Use this when not on a domain (standalone or workgroup machine).  
  Runs under a dedicated local user account (e.g. `MACHINE\ServiceUser`) with stored credentials.  
  ✅ Recommended if the utility must access **network shares with a local user account**.

- **LogFileCollector_NetworkService.xml**  
  Runs as the built-in `NT AUTHORITY\NetworkService` account.  
  Uses the computer account (`MACHINE$`) for network access.  
  ✅ Only works if the **machine account is granted rights on the network share**.  
  ⚠️ Limited local rights.

- **LogFileCollector_System.xml**  
  Runs as the built-in `NT AUTHORITY\SYSTEM` account.  
  Has full local privileges.  
  ✅ Suitable if the utility only needs **local access**.  
  ⚠️ Cannot use user credentials on network shares (only the machine account).

---

**Summary:**  
- Need domain user access → use **_Domain**.  
- Standalone machine with user credentials → use **_Local**.  
- Want to run as built-in service account → use **_NetworkService** or **_System** depending on required privileges.  

---

## 📝 License

# Virinco Software License (Summary)

This project is licensed under the **Virinco Software License Agreement**.  
See the full text in [`LICENSE.txt`](LICENSE.txt) for details.

### Permissions ✅
- Free to use for personal and commercial purposes  
- Free to view and modify the source code  
- Free to submit contributions (pull requests)  

### Restrictions ❌
- Redistribution, sublicensing, or resale outside Virinco AS channels is not allowed  
- Modified versions may not be presented as official Virinco products without permission  

### Conditions ⚖️
- Virinco AS retains full ownership of the Software and accepted contributions  
- Provided *“AS IS”*, without warranty or liability  

---

For questions or contributions, please open an issue or pull request on GitHub.
