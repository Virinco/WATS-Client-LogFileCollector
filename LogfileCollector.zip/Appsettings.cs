﻿using System.IO;
using System.Text.Json;

namespace LogFileCollector
{
    public class LoggingSettings
    {
        public string LogFilePath { get; set; } = "log.txt";
        public string LogOutputTemplate { get; set; } =
            "[{Timestamp:HH:mm:ss} {Level:u3}] {Message:lj}{NewLine}{Exception}";
        public string LogLevel { get; set; } = "Information";
        public string RollingInterval { get; set; } = "Day";
        public int? RetainedFileCountLimit { get; set; } = 10;
        public bool Verbose { get; set; } = false;
    }

    public class Appsettings
    {
        public static Appsettings Current { get; private set; } = new Appsettings();

        public string SourceFolder { get; set; } = "";
        public string TargetFolder { get; set; } = "";
        public string Filter { get; set; } = "*.*";
        public bool IncludeSubdirectories { get; set; } = true;
        public int FileCreatedDelayMs { get; set; } = 500;
        public string DatabasePath { get; set; } = "copied.db";
        public string RenameStrategy { get; set; } = "counter";
        public LoggingSettings Logging { get; set; } = new LoggingSettings();

        public static void Load(string path)
        {
            var json = File.ReadAllText(path);
            Current = JsonSerializer.Deserialize<Appsettings>(json,
                new JsonSerializerOptions { PropertyNameCaseInsensitive = true })
                ?? new Appsettings();
        }
    }
}
