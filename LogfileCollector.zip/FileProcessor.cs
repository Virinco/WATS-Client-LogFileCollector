﻿using System;
using System.Diagnostics;
using System.IO;
using Serilog;

namespace LogFileCollector
{
    public class FileProcessor
    {
        private readonly string _targetFolder;
        private readonly Database _db;
        private readonly string _renameStrategy;
        private readonly bool _verbose;

        public FileProcessor(string targetFolder, Database db, string renameStrategy, bool verbosePerFile)
        {
            _targetFolder = targetFolder;
            _db = db;
            _renameStrategy = (renameStrategy ?? "counter").ToLowerInvariant();
            _verbose = verbosePerFile;
            Directory.CreateDirectory(_targetFolder);
        }

        public void RescanFolder(string sourceFolder, string filter, bool includeSubdirs)
        {
            int scanned = 0, copied = 0, skipped = 0, errors = 0;
            var sw = Stopwatch.StartNew();

            var option = includeSubdirs ? SearchOption.AllDirectories : SearchOption.TopDirectoryOnly;
            foreach (var file in Directory.EnumerateFiles(sourceFolder, filter, option))
            {
                scanned++;
                try { ProcessOne(file, ref copied, ref skipped); }
                catch (Exception ex) { errors++; Log.Error(ex, "Error processing {File}", file); }
            }

            sw.Stop();
            Log.Information("Rescan summary: scanned={Scanned}, copied={Copied}, skipped={Skipped}, errors={Errors}, elapsed={Elapsed:0.0}s",
                scanned, copied, skipped, errors, sw.Elapsed.TotalSeconds);
        }

        public void RunWatcher(string sourceFolder, string filter, bool includeSubdirs, int createdDelayMs)
        {
            var fsw = new FileSystemWatcher(sourceFolder, filter)
            {
                IncludeSubdirectories = includeSubdirs,
                EnableRaisingEvents = true
            };

            fsw.Created += (s, e) =>
            {
                try
                {
                    System.Threading.Thread.Sleep(createdDelayMs);
                    int copied = 0, skipped = 0;
                    ProcessOne(e.FullPath, ref copied, ref skipped);
                }
                catch (Exception ex) { Log.Error(ex, "Watcher error for {File}", e.FullPath); }
            };

            Log.Information("Watcher running. Press Ctrl+C to stop.");
            System.Threading.Thread.Sleep(System.Threading.Timeout.Infinite);
        }

        private void ProcessOne(string fullPath, ref int copied, ref int skipped)
        {
            if (!File.Exists(fullPath))
                return;

            var info = new FileInfo(fullPath);
            var lastWriteUtc = info.LastWriteTimeUtc;
            var length = info.Length;

            if (_db.HasFile(fullPath, lastWriteUtc, length))
            {
                skipped++;
                if (_verbose) Log.Debug("Skipped (already copied): {File}", fullPath);
                return;
            }

            string destPath = GetDestination(fullPath);
            File.Copy(fullPath, destPath, overwrite: false);
            _db.AddFile(fullPath, lastWriteUtc, length);

            copied++;
            if (_verbose) Log.Information("Copied: {Src} -> {Dest}", fullPath, destPath);
        }

        private string GetDestination(string fullPath)
        {
            string name = Path.GetFileNameWithoutExtension(fullPath);
            string ext = Path.GetExtension(fullPath);
            string dest = Path.Combine(_targetFolder, name + ext);

            if (!File.Exists(dest)) return dest;

            return _renameStrategy switch
            {
                "timestamp" => Path.Combine(_targetFolder, $"{name}_{DateTime.UtcNow:yyyyMMdd-HHmmss}{ext}"),
                "guid" => Path.Combine(_targetFolder, $"{name}_{Guid.NewGuid():N}{ext}"),
                _ => GetCounterPath(name, ext)
            };
        }

        private string GetCounterPath(string name, string ext)
        {
            int i = 1;
            string candidate;
            do { candidate = Path.Combine(_targetFolder, $"{name}_{i}{ext}"); i++; }
            while (File.Exists(candidate));
            return candidate;
        }
    }
}
