﻿using System;
using System.IO;
using System.Linq;
using Serilog;
using Serilog.Events;

namespace LogFileCollector
{
    class Program
    {
        static void Main(string[] args)
        {
            // Resolve ProgramData dir
            string dataDir = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),
                "Virinco", "WATS", "LogFileCollector");
            Directory.CreateDirectory(dataDir);

            // Load config
            string configPath = Path.Combine(dataDir, "appsettings.json");
            if (!File.Exists(configPath))
            {
                Console.Error.WriteLine("Missing config: " + configPath);
                return;
            }
            Appsettings.Load(configPath);

            // Resolve DB + Log paths
            string dbPath = ResolveUnderDataDir(Appsettings.Current.DatabasePath, dataDir);
            string logPath = ResolveUnderDataDir(Appsettings.Current.Logging.LogFilePath, dataDir);

            // Map log level
            var level = ToSerilogLevel(Appsettings.Current.Logging.LogLevel);

            // Map rolling interval
            var interval = ToRollingInterval(Appsettings.Current.Logging.RollingInterval);

            // Setup logging
            Log.Logger = new LoggerConfiguration()
                .MinimumLevel.Is(level)
                .WriteTo.Console(outputTemplate: Appsettings.Current.Logging.LogOutputTemplate)
                .WriteTo.File(
                    logPath,
                    outputTemplate: Appsettings.Current.Logging.LogOutputTemplate,
                    rollingInterval: interval,
                    retainedFileCountLimit: Appsettings.Current.Logging.RetainedFileCountLimit)
                .CreateLogger();

            try
            {
                Log.Information("LogFileCollector starting…");

                bool reset = args.Contains("--reset", StringComparer.OrdinalIgnoreCase);
                bool rescan = args.Contains("--rescan", StringComparer.OrdinalIgnoreCase);

                if (reset && File.Exists(dbPath))
                {
                    File.Delete(dbPath);
                    Log.Warning("Database reset: {DbPath}", dbPath);
                    return;
                }

                var db = new Database(dbPath);
                db.Initialize();

                var processor = new FileProcessor(
                    Appsettings.Current.TargetFolder,
                    db,
                    Appsettings.Current.RenameStrategy,
                    Appsettings.Current.Logging.Verbose);

                if (rescan)
                {
                    Log.Information("Rescan starting. Source={Source}, Filter={Filter}, Subdirs={Subdirs}",
                        Appsettings.Current.SourceFolder,
                        Appsettings.Current.Filter,
                        Appsettings.Current.IncludeSubdirectories);

                    processor.RescanFolder(
                        Appsettings.Current.SourceFolder,
                        Appsettings.Current.Filter,
                        Appsettings.Current.IncludeSubdirectories);

                    Log.Information("Rescan complete. Switching to watcher mode...");
                }

                // Always continue into watcher mode unless reset was specified
                Log.Information("Watcher starting. Source={Source}, Filter={Filter}, Subdirs={Subdirs}",
                    Appsettings.Current.SourceFolder,
                    Appsettings.Current.Filter,
                    Appsettings.Current.IncludeSubdirectories);

                processor.RunWatcher(
                    Appsettings.Current.SourceFolder,
                    Appsettings.Current.Filter,
                    Appsettings.Current.IncludeSubdirectories,
                    Appsettings.Current.FileCreatedDelayMs);
            }
            catch (Exception ex)
            {
                Log.Fatal(ex, "Fatal error");
            }
            finally
            {
                Log.Information("LogFileCollector stopped.");
                Log.CloseAndFlush();
            }
        }

        private static string ResolveUnderDataDir(string path, string dataDir)
            => Path.IsPathRooted(path) ? path : Path.Combine(dataDir, path);

        private static LogEventLevel ToSerilogLevel(string? s) => (s ?? "").ToLower() switch
        {
            "verbose" => LogEventLevel.Verbose,
            "debug" => LogEventLevel.Debug,
            "warning" => LogEventLevel.Warning,
            "error" => LogEventLevel.Error,
            "fatal" => LogEventLevel.Fatal,
            _ => LogEventLevel.Information
        };

        private static RollingInterval ToRollingInterval(string? s) => (s ?? "").ToLower() switch
        {
            "hour" => RollingInterval.Hour,
            "month" => RollingInterval.Month,
            "year" => RollingInterval.Year,
            "infinite" => RollingInterval.Infinite,
            _ => RollingInterval.Day
        };
    }
}
