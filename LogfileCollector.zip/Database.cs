﻿using System;
using System.IO;
using Microsoft.Data.Sqlite;

namespace LogFileCollector
{
    public class Database
    {
        private readonly string _dbPath;
        private readonly string _connectionString;

        public Database(string dbPath)
        {
            _dbPath = dbPath;
            _connectionString = $"Data Source={_dbPath}";
        }

        public void Initialize()
        {
            Directory.CreateDirectory(Path.GetDirectoryName(_dbPath) ?? ".");

            using (var conn = new SqliteConnection(_connectionString))
            {
                conn.Open();
                using (var cmd = conn.CreateCommand())
                {
                    cmd.CommandText = @"
                        CREATE TABLE IF NOT EXISTS CopiedFiles (
                            Id INTEGER PRIMARY KEY AUTOINCREMENT,
                            FullPath TEXT NOT NULL,
                            LastWriteTimeUtc TEXT NOT NULL,
                            Length INTEGER NOT NULL,
                            UNIQUE(FullPath, LastWriteTimeUtc, Length)
                        );";
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public bool HasFile(string fullPath, DateTime lastWriteUtc, long length)
        {
            using (var conn = new SqliteConnection(_connectionString))
            {
                conn.Open();
                using (var cmd = conn.CreateCommand())
                {
                    cmd.CommandText = @"
                        SELECT 1 FROM CopiedFiles 
                        WHERE FullPath = $path 
                          AND LastWriteTimeUtc = $lastWrite
                          AND Length = $length
                        LIMIT 1;";
                    cmd.Parameters.AddWithValue("$path", fullPath);
                    cmd.Parameters.AddWithValue("$lastWrite", lastWriteUtc.ToString("o"));
                    cmd.Parameters.AddWithValue("$length", length);

                    var result = cmd.ExecuteScalar();
                    return result != null;
                }
            }
        }

        public void AddFile(string fullPath, DateTime lastWriteUtc, long length)
        {
            using (var conn = new SqliteConnection(_connectionString))
            {
                conn.Open();
                using (var cmd = conn.CreateCommand())
                {
                    cmd.CommandText = @"
                        INSERT OR IGNORE INTO CopiedFiles (FullPath, LastWriteTimeUtc, Length) 
                        VALUES ($path, $lastWrite, $length);";
                    cmd.Parameters.AddWithValue("$path", fullPath);
                    cmd.Parameters.AddWithValue("$lastWrite", lastWriteUtc.ToString("o"));
                    cmd.Parameters.AddWithValue("$length", length);
                    cmd.ExecuteNonQuery();
                }
            }
        }
    }
}
